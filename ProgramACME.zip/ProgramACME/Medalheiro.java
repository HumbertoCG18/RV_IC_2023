import java.util.ArrayList;
import java.util.List;
/*
 *  classe que representa  um atleta na com
  */
public class Medalheiro {
    private List<Medalha> medalhas;

    public Medalheiro() {
        this.medalhas = new ArrayList<>();
    }

    public boolean cadastraMedalha(Medalha medalha) {
        // Adicione a medalha à lista de medalhas
        return this.medalhas.add(medalha);
    }

    public Medalha consultaMedalha(int codigo) {
        // Busque a medalha pelo código
        for (Medalha medalha : this.medalhas) {
            if (medalha.getCodigo() == codigo) {
                return medalha;
            }
        }
        return null; // Retorna null se a medalha não for encontrada
    }

    // Outros métodos necessários para gerenciar as medalhas
}
