import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ACMESports {
    private Medalheiro medalheiro;
    private Plantel plantel;
    public ACMESports() {
        medalheiro = new Medalheiro();
        plantel = new Plantel();
    }
    public void executar() {
        try {
            File inputFile = new File("dadosin.txt");
            Scanner scanner = new Scanner(inputFile);
            FileWriter writer = new FileWriter("dadosoutNew.txt");
            // Passo 1: Cadastrar atletas
            while (scanner.hasNextLine()) {
                int numero = Integer.parseInt(scanner.nextLine());
                if (numero == -1) {
                break;
                }
                String nome = scanner.nextLine();
                String pais = scanner.nextLine();
                Atleta atleta = new Atleta(numero, nome, pais);
                boolean cadastrado = plantel.cadastraAtleta(atleta);
                if (cadastrado) {
                writer.write("1:" + numero + "," + nome + "," + pais + "\n");
                }
            }
            // Passo 2: Cadastrar medalhas
            while (scanner.hasNextLine()) {
                int codigo = Integer.parseInt(scanner.nextLine());
                if (codigo == -1) {
                break;
                }
                String tipo = scanner.nextLine();
                boolean individual = Boolean.parseBoolean(scanner.nextLine());
                String modalidade = scanner.nextLine();
                Medalha medalha = new Medalha(codigo, tipo, individual, modalidade);
                boolean cadastrado = medalheiro.cadastraMedalha(medalha);
                if (cadastrado) {
                writer.write("2:" + codigo + "," + tipo + "," + individual + "," + modalidade + "\n");
                }
            }
            // Passo 3: Cadastrar medalhas e atletas correspondentes
            while (scanner.hasNextLine()) {
                int codigoMedalha = Integer.parseInt(scanner.nextLine());
                if (codigoMedalha == -1) {
                break;
                }
                int numeroAtleta = Integer.parseInt(scanner.nextLine());
                Medalha medalha = medalheiro.consultaMedalha(codigoMedalha);
                Atleta atleta = plantel.consultaAtleta(numeroAtleta);
                //Aparecer apenas o atrleta de número 55
                if (medalha != null && atleta != null) {
                atleta.adicionaMedalha(medalha);
                medalha.adicionaAtleta(atleta);
                writer.write("3:" + codigoMedalha + "," + numeroAtleta + "\n");
                }
            }

/*
Passo 4
Passo 5
Passo 6
Passo 7
Passo 8
Passo 9
Passo 10
*/
            writer.close();
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        ACMESports acmeSports = new ACMESports();
        acmeSports.executar();
    }
}
