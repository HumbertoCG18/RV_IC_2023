public class Atleta {
    private int numero;
    private String nome;
    private String pais;
    private Medalha[] medalhas;

    public Atleta(int numero, String nome, String pais) {
        this.numero = numero;
        this.nome = nome;
        this.pais = pais;
        this.medalhas = new Medalha[0];
    }

    // Getters e setters
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public void adicionaMedalha(Medalha medalha) {
        // Criar um novo array com tamanho aumentado para armazenar a nova medalha
        Medalha[] novoArray = new Medalha[medalhas.length + 1];
        
        // Copiar as medalhas existentes para o novo array
        for (int i = 0; i < medalhas.length; i++) {
            novoArray[i] = medalhas[i];
        }
        
        // Adicionar a nova medalha ao final do novo array
        novoArray[medalhas.length] = medalha;
        
        // Atualizar a referência para o novo array
        medalhas = novoArray;
    }

    // Retorna a quantidade de medalhas do atleta
    public int consultaQuantidadeMedalhas() {
        return medalhas.length;
    }
}
