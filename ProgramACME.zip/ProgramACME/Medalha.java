import java.util.ArrayList;
import java.util.List;

public class Medalha {
    private int codigo;
    private String tipo;
    private boolean individual;
    private String modalidade;
    private List<Atleta> atletas;

    public Medalha(int codigo, String tipo, boolean individual, String modalidade) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.individual = individual;
        this.modalidade = modalidade;
        this.atletas = new ArrayList<>();
    }

    public int getCodigo() {
        return codigo;
    }

    public String getTipo() {
        return tipo;
    }

    public boolean isIndividual() {
        return individual;
    }

    public String getModalidade() {
        return modalidade;
    }

    public List<Atleta> getAtletas() {
        return atletas;
    }

    public void adicionaAtleta(Atleta atleta) {
        this.atletas.add(atleta);
    }
}
