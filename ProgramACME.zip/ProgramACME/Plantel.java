import java.util.ArrayList;
import java.util.List;

public class Plantel {
    private List<Atleta> atletas;

    public Plantel() {
        this.atletas = new ArrayList<>();
    }

    public boolean cadastraAtleta(Atleta atleta) {
        // Adicione o atleta à lista de atletas
        return this.atletas.add(atleta);
    }

    public Atleta consultaAtleta(String nome) {
        // Busque o atleta pelo nome
        for (Atleta atleta : this.atletas) {
            if (atleta.getNome().equals(nome)) {
                return atleta;
            }
        }
        return null; // Retorna null se o atleta não for encontrado
    }

    public Atleta consultaAtleta(int numero) {
        // Busque o atleta pelo número
        for (Atleta atleta : this.atletas) {
            if (atleta.getNumero() == numero) {
                return atleta;
            }
        }
        return null; // Retorna null se o atleta não for encontrado
    }

    // Outros métodos necessários para gerenciar os atletas
}
