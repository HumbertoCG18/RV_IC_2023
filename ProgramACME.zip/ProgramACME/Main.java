public class Main {
    public static void main(String[] args) {
        ACMESports acmeSports = new ACMESports();
        acmeSports.executar();
    }
}
